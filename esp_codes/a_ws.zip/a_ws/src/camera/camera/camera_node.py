#!/usr/bin/env python3

import cv2

import rclpy
from rclpy.node import Node

from sensor_msgs.msg import Image
from cv_bridge import CvBridge


class CameraNode(Node):

    def __init__(self):

        super().__init__('camera_node')

        self.cap = cv2.VideoCapture(0)

        if not self.cap.isOpened():

            self.get_logger().error(
                'Failed to open camera'
            )

            return

        self.bridge = CvBridge()

        self.image_pub = self.create_publisher(
            Image,
            'camera_raw',
            10
        )

        self.timer = self.create_timer(
            0.03,
            self.process_frame
        )

        self.get_logger().info(
            'Camera node started'
        )

    def process_frame(self):

        ret, frame = self.cap.read()

        if not ret:
            return

        # Publish image
        msg = self.bridge.cv2_to_imgmsg(
            frame,
            encoding='bgr8'
        )

        self.image_pub.publish(msg)

    def destroy_node(self):

        if self.cap.isOpened():
            self.cap.release()

        super().destroy_node()


def main(args=None):

    rclpy.init(args=args)

    node = CameraNode()

    try:

        rclpy.spin(node)

    except KeyboardInterrupt:
        pass

    node.destroy_node()


if __name__ == '__main__':
    main()
