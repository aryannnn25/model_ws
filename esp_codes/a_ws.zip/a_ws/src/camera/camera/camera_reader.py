#!/usr/bin/env python3

import cv2

import rclpy
from rclpy.node import Node

from sensor_msgs.msg import Image
from cv_bridge import CvBridge


class CameraViewer(Node):

    def __init__(self):

        super().__init__('camera_viewer')

        self.bridge = CvBridge()

        self.subscription = self.create_subscription(
            Image,
            'camera_raw',
            self.image_callback,
            10
        )

        cv2.namedWindow(
            "Camera Feed",
            cv2.WINDOW_NORMAL
        )

        cv2.resizeWindow(
            "Camera Feed",
            1280,
            720
        )

        self.get_logger().info(
            'Camera viewer started'
        )

    def image_callback(self, msg):

        try:

            frame = self.bridge.imgmsg_to_cv2(
                msg,
                desired_encoding='bgr8'
            )

            cv2.imshow(
                "Camera Feed",
                frame
            )

            key = cv2.waitKey(1)

            if key == 27:  # ESC
                self.get_logger().info(
                    'ESC pressed'
                )
                rclpy.shutdown()

        except Exception as e:

            self.get_logger().error(
                f'Error converting image: {e}'
            )

    def destroy_node(self):

        cv2.destroyAllWindows()

        super().destroy_node()


def main(args=None):

    rclpy.init(args=args)

    node = CameraViewer()

    try:

        rclpy.spin(node)

    except KeyboardInterrupt:

        pass

    node.destroy_node()

    rclpy.shutdown()


if __name__ == '__main__':

    main()