#!/usr/bin/env python3

import can
import time

bus = can.interface.Bus(
    channel='can0',
    interface='socketcan'
)

count = 0
start = time.time()

while True:

    msg = bus.recv()

    if msg.arbitration_id == 0x60A:

        count += 1

        elapsed = time.time() - start

        if elapsed >= 5.0:

            rate = count / elapsed

            print(
                f"Frames: {count}, "
                f"Time: {elapsed:.2f}s, "
                f"Rate: {rate:.2f} Hz"
            )

            count = 0
            start = time.time()