#!/usr/bin/env python3

import can

import rclpy
from rclpy.node import Node

from radar_msgs.msg import RadarStatus
from radar_msgs.msg import RadarTarget


class RadarNode(Node):

    def __init__(self):

        super().__init__('radar_node')

        self.status_pub = self.create_publisher(
            RadarStatus,
            '/radar/status',
            10
        )

        self.target_pub = self.create_publisher(
            RadarTarget,
            '/radar/raw',
            100
        )

        self.bus = can.interface.Bus(
            channel='can0',
            interface='socketcan'
        )

        self.timer = self.create_timer(
            0.001,
            self.read_can
        )

        self.get_logger().info(
            'Radar node started'
        )

    def decode_target(self, data):

        b = data

        target = RadarTarget()

        target.stamp = (
            self.get_clock().now().to_msg()
        )

        # Object ID
        target.object_id = b[0]

        # Longitudinal Distance
        dist_long_raw = (
            (b[1] << 5)
            | (b[2] >> 3)
        )

        target.dist_long = (
            dist_long_raw * 0.2
            - 500.0
        )

        # Lateral Distance
        dist_lat_raw = (
            ((b[2] & 0x07) << 8)
            | b[3]
        )

        target.dist_lat = (
            dist_lat_raw * 0.2
            - 204.6
        )

        # Longitudinal Velocity
        vrel_long_raw = (
            (b[4] << 2)
            | (b[5] >> 6)
        )

        target.vrel_long = (
            vrel_long_raw * 0.25
            - 128.0
        )

        # Lateral Velocity
        vrel_lat_raw = (
            ((b[5] & 0x3F) << 3)
            | (b[6] >> 5)
        )

        target.vrel_lat = (
            vrel_lat_raw * 0.25
            - 64.0
        )

        # Dynamic Property
        target.dyn_prop = (
            b[6] & 0x07
        )

        # Sector
        target.sector = (
            (b[6] >> 3)
            & 0x03
        )

        # RCS
        target.rcs = (
            b[7] * 0.5
            - 64.0
        )

        return target

    def publish_status(self, data):

        status = RadarStatus()

        status.stamp = (
            self.get_clock().now().to_msg()
        )

        status.object_count = data[0]

        status.frame_counter = (
            (data[1] << 8)
            | data[2]
        )

        self.status_pub.publish(
            status
        )

    def read_can(self):

        try:

            msg = self.bus.recv(
                timeout=0.0
            )

            if msg is None:
                return

            if msg.arbitration_id == 0x60A:

                self.publish_status(
                    msg.data
                )

            elif msg.arbitration_id == 0x60B:

                target = self.decode_target(
                    msg.data
                )

                self.target_pub.publish(
                    target
                )

        except Exception as e:

            self.get_logger().error(
                f'CAN Error: {e}'
            )

    def destroy_node(self):

        try:
            self.bus.shutdown()
        except Exception:
            pass

        super().destroy_node()


def main(args=None):

    rclpy.init(args=args)

    node = RadarNode()

    try:

        rclpy.spin(node)

    except KeyboardInterrupt:

        pass

    node.destroy_node()

    rclpy.shutdown()


if __name__ == '__main__':
    main()