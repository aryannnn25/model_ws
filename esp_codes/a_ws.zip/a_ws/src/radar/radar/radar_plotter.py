#!/usr/bin/env python3

import rclpy
from rclpy.node import Node

from radar_msgs.msg import RadarTarget

import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

import numpy as np

import threading
import time
import math

# ==========================================================
# FILTER ENABLES
# ==========================================================

ENABLE_TRACK_AGE_FILTER = False
ENABLE_HIT_COUNT_FILTER = True
ENABLE_ROI_FILTER = True
ENABLE_CLOSING_FILTER = True
ENABLE_RCS_FILTER = True
ENABLE_DEADZONE_FILTER = True
ENABLE_TRAJECTORY_FILTER = True

# ==========================================================
# FILTER PARAMETERS
# ==========================================================

MIN_HITS = 15

MAX_LATERAL_DISTANCE = 1.0

MIN_CLOSING_SPEED = 4.0

MIN_RCS = 15.0

MIN_DETECTION_DISTANCE = 4.0

TARGET_TIMEOUT = 1.0

# ==========================================================
# TRAJECTORY FILTER PARAMETERS
# ==========================================================
# Rejects targets that pass the instantaneous closing-speed filter
# on a single noisy vy reading, but whose actual range (y) is NOT
# decreasing over time -- e.g. static clutter with a spurious
# velocity glitch. This catches persistent ghosts that "spawn and
# stay" or drift laterally rather than truly closing on the vehicle.
#
# Checks the average range-decrease rate over a longer window
# (TRAJECTORY_WINDOW_SEC) and requires it to meet the same
# MIN_CLOSING_SPEED bar used by the instantaneous filter, so the
# two stay logically consistent.
#
# Targets younger than the window simply pass this filter (not
# enough history yet to judge) -- MIN_HITS already provides a
# baseline maturity gate before a target can be valid at all.

TRAJECTORY_WINDOW_SEC = 1.0

# ==========================================================
# KALMAN FILTER PARAMETERS
# ==========================================================
# Applied only to targets that already pass target_passes_filters().
# Constant-velocity model on state [x, y, vx, vy].
#
# Pipeline order is: raw detection -> existing threat filters -> Kalman.
# A target must be "valid" before it gets a Kalman instance at all.

RADAR_RATE_HZ = 30.0
KALMAN_DT = 1.0 / RADAR_RATE_HZ

# Process noise: how much we trust the constant-velocity assumption.
# Higher = filter adapts faster to real changes but smooths less.
# Separate values for position vs velocity process noise.
KALMAN_PROCESS_NOISE_POS = 0.05
KALMAN_PROCESS_NOISE_VEL = 0.3

# Measurement noise: how noisy we believe raw radar x/y/vx/vy are.
# Higher = filter trusts its own prediction more, trusts new measurement less.
KALMAN_MEASUREMENT_NOISE_POS = 0.15
KALMAN_MEASUREMENT_NOISE_VEL = 0.5

# Initial covariance: how uncertain we are right when a track is created.
# Kept high so the filter converges quickly on the first few measurements.
KALMAN_INITIAL_COVARIANCE = 5.0

# Grace period: how long (seconds) a target's Kalman instance survives
# after the target drops out of "valid" status. Prevents flicker at the
# filter boundary from destroying accumulated smoothing. This is
# independent of, and shorter than, TARGET_TIMEOUT (which governs when
# the raw track itself is removed).
KALMAN_GRACE_PERIOD = 0.3

# ==========================================================
# DISPLAY SETTINGS
# ==========================================================

XLIM_MIN = -3.0
XLIM_MAX = 3.0

YLIM_MIN = 0
YLIM_MAX = 40

UPDATE_INTERVAL_MS = 100

# ==========================================================
# DISPLAY OPTIONS
# ==========================================================

SHOW_FILTERED_TARGETS = False
SHOW_LABELS = True
SHOW_VELOCITY_ARROWS = True


class KalmanFilterCV:
    """
    Constant-velocity Kalman filter for a single target.
    State: [x, y, vx, vy]
    Measurement: [x, y, vx, vy] (radar gives us position and relative
    velocity directly, so H is identity and this stays a simple,
    well-conditioned 4-state/4-measurement filter).
    """

    def __init__(self, x, y, vx, vy, dt):

        self.dt = dt

        # State vector [x, y, vx, vy]
        self.state = np.array([x, y, vx, vy], dtype=float)

        # State transition matrix (constant velocity model)
        self.F = np.array([
            [1.0, 0.0, dt, 0.0],
            [0.0, 1.0, 0.0, dt],
            [0.0, 0.0, 1.0, 0.0],
            [0.0, 0.0, 0.0, 1.0],
        ])

        # Measurement matrix (we observe the full state directly)
        self.H = np.eye(4)

        # Process noise covariance
        self.Q = np.diag([
            KALMAN_PROCESS_NOISE_POS,
            KALMAN_PROCESS_NOISE_POS,
            KALMAN_PROCESS_NOISE_VEL,
            KALMAN_PROCESS_NOISE_VEL,
        ])

        # Measurement noise covariance
        self.R = np.diag([
            KALMAN_MEASUREMENT_NOISE_POS,
            KALMAN_MEASUREMENT_NOISE_POS,
            KALMAN_MEASUREMENT_NOISE_VEL,
            KALMAN_MEASUREMENT_NOISE_VEL,
        ])

        # State covariance, initialized high so the filter converges
        # quickly on the first few real measurements.
        self.P = np.eye(4) * KALMAN_INITIAL_COVARIANCE

    def predict(self):

        self.state = self.F @ self.state
        self.P = self.F @ self.P @ self.F.T + self.Q

    def update(self, x, y, vx, vy):

        z = np.array([x, y, vx, vy], dtype=float)

        y_residual = z - (self.H @ self.state)

        S = self.H @ self.P @ self.H.T + self.R
        K = self.P @ self.H.T @ np.linalg.inv(S)

        self.state = self.state + K @ y_residual
        self.P = (np.eye(4) - K @ self.H) @ self.P

    def get_state(self):

        # Returns (x, y, vx, vy)
        return (
            self.state[0],
            self.state[1],
            self.state[2],
            self.state[3],
        )


class RadarPlotter(Node):

    def __init__(self):

        super().__init__('radar_plotter')

        self.targets = {}
        self.lock = threading.Lock()

        # Kalman filter instances, keyed by object_id.
        # Only created once a target has passed target_passes_filters().
        self.kalman_filters = {}

        self.subscription = self.create_subscription(
            RadarTarget,
            '/radar/raw',
            self.callback,
            100
        )

        self.get_logger().info(
            'Radar plotter started'
        )

    def callback(self, msg):

        now = time.time()

        with self.lock:

            if msg.object_id in self.targets:

                first_seen = self.targets[msg.object_id]['first_seen']
                hits = self.targets[msg.object_id]['hits'] + 1

                y_history = self.targets[msg.object_id]['y_history']

                # Owned by the plotting loop's grace-period logic, not
                # the callback -- preserve it across raw updates.
                kalman_miss_since = self.targets[msg.object_id]['kalman_miss_since']

            else:

                first_seen = now
                hits = 1

                y_history = []

                kalman_miss_since = None

            # Append this raw measurement to the rolling history, then
            # trim anything older than the trajectory check's window.
            # Uses raw y (not Kalman-smoothed) since this runs at
            # callback time, before any filtering or smoothing happens.

            y_history.append((now, msg.dist_long))

            cutoff = now - TRAJECTORY_WINDOW_SEC

            y_history = [
                (t, y) for (t, y) in y_history if t >= cutoff
            ]

            self.targets[msg.object_id] = {

                'x': msg.dist_lat,
                'y': msg.dist_long,

                'vx': msg.vrel_lat,
                'vy': msg.vrel_long,

                'rcs': msg.rcs,
                'dyn_prop': msg.dyn_prop,
                'sector': msg.sector,

                'first_seen': first_seen,
                'last_seen': now,

                'hits': hits,

                'y_history': y_history,

                'kalman_miss_since': kalman_miss_since
            }


node_ref = None
anim = None


def trajectory_is_consistent(target):
    """
    Checks whether the target's range (y) has actually been decreasing
    over the trajectory window at a rate consistent with a real closing
    object, as opposed to a static/spurious detection that only passed
    the instantaneous closing-speed filter on a noisy single-frame vy
    reading.

    Uses raw y_history (recorded in the callback), not Kalman-smoothed
    state, so this stays purely a gatekeeping filter ahead of Kalman in
    the pipeline.

    Targets with less than TRAJECTORY_WINDOW_SEC of history pass by
    default -- MIN_HITS already provides a baseline maturity gate, and
    this filter's job is to catch persistent ghosts over time, not to
    penalize genuinely new tracks for being new.
    """

    y_history = target['y_history']

    if len(y_history) < 2:
        return True

    t_oldest, y_oldest = y_history[0]
    t_newest, y_newest = y_history[-1]

    elapsed = t_newest - t_oldest

    if elapsed < TRAJECTORY_WINDOW_SEC:
        return True

    if elapsed <= 0:
        return True

    avg_closing_rate = (y_oldest - y_newest) / elapsed

    return avg_closing_rate >= MIN_CLOSING_SPEED


def target_passes_filters(target, track_age):

    x = target['x']
    y = target['y']
    vy = target['vy']
    hits = target['hits']
    rcs = target['rcs']

    valid = True

    if ENABLE_TRACK_AGE_FILTER:
        if track_age < MIN_TRACK_AGE_SEC:
            valid = False

    if ENABLE_HIT_COUNT_FILTER:
        if hits < MIN_HITS:
            valid = False

    if ENABLE_ROI_FILTER:
        if abs(x) > MAX_LATERAL_DISTANCE:
            valid = False

    if ENABLE_CLOSING_FILTER:
        if vy > -MIN_CLOSING_SPEED:
            valid = False

    if ENABLE_RCS_FILTER:
        if rcs < MIN_RCS:
            valid = False

    if ENABLE_DEADZONE_FILTER:
        if y < MIN_DETECTION_DISTANCE:
            valid = False

    if ENABLE_TRAJECTORY_FILTER:
        if not trajectory_is_consistent(target):
            valid = False

    return valid


def update(frame):

    global node_ref

    plt.cla()

    plt.xlim(XLIM_MIN, XLIM_MAX)
    plt.ylim(YLIM_MIN, YLIM_MAX)

    plt.grid(
        True,
        color='#333333',
        linestyle='--',
        linewidth=0.5
    )

    plt.xlabel(
        "Lateral Distance (m)",
        color='#e0e0e0',
        fontsize=10,
        fontweight='bold'
    )

    plt.ylabel(
        "Longitudinal Distance (m)",
        color='#e0e0e0',
        fontsize=10,
        fontweight='bold'
    )

    plt.title(
        "SR73 Radar Targets - Filtered Display",
        color='#ffffff',
        fontsize=12,
        fontweight='bold',
        pad=10
    )

    # Radar origin

    plt.scatter(
        0,
        0,
        color='#00e676',
        marker='^',
        s=120,
        label='Radar Sensor',
        zorder=10
    )

    now = time.time()

    valid_count = 0
    total_count = 0

    with node_ref.lock:

        remove_ids = []
        kalman_remove_ids = []

        # ------------------------------------------------------
        # Step 1: advance every live Kalman filter by one predict
        # step, regardless of whether that target is valid this
        # cycle. This keeps velocity estimates consistent even
        # through a brief flicker out of "valid".
        # ------------------------------------------------------

        for kid, kf in node_ref.kalman_filters.items():
            kf.predict()

        for target_id, target in node_ref.targets.items():

            age_since_update = now - target['last_seen']

            if age_since_update > TARGET_TIMEOUT:

                remove_ids.append(target_id)
                continue

            total_count += 1

            track_age = now - target['first_seen']

            x = target['x']
            y = target['y']

            vx = target['vx']
            vy = target['vy']

            rcs = target['rcs']
            hits = target['hits']

            dyn_prop = target['dyn_prop']
            sector = target['sector']

            valid = target_passes_filters(
                target,
                track_age
            )

            # --------------------------------------------------
            # Kalman handling: only valid targets get a filter
            # instance. Existing instances are corrected here
            # with this cycle's measurement.
            # --------------------------------------------------

            if valid:

                valid_count += 1

                if target_id not in node_ref.kalman_filters:

                    node_ref.kalman_filters[target_id] = KalmanFilterCV(
                        x, y, vx, vy, KALMAN_DT
                    )

                else:

                    node_ref.kalman_filters[target_id].update(x, y, vx, vy)

                # Use smoothed state for everything downstream
                # (plotting, labels, future control logic).
                x, y, vx, vy = node_ref.kalman_filters[target_id].get_state()

                target['kalman_miss_since'] = None

            else:

                # Target exists but failed this cycle's filter check.
                # If it has a live Kalman instance, start (or continue)
                # the grace-period clock instead of destroying it
                # immediately.
                if target_id in node_ref.kalman_filters:

                    if target.get('kalman_miss_since') is None:
                        target['kalman_miss_since'] = now

                    miss_duration = now - target['kalman_miss_since']

                    if miss_duration > KALMAN_GRACE_PERIOD:
                        kalman_remove_ids.append(target_id)

            v_mag = math.sqrt(vx * vx + vy * vy)

            # Skip plotting filtered targets completely

            if not valid and not SHOW_FILTERED_TARGETS:
                continue

            if valid:

                point_color = '#00ff00'
                label_color = '#00ff00'

            else:

                point_color = '#ffff00'
                label_color = '#ffff00'

            # --------------------------------------------------
            # Target point
            # --------------------------------------------------

            plt.scatter(
                x,
                y,
                color=point_color,
                edgecolors='#ffffff',
                s=90,
                zorder=3
            )

            # --------------------------------------------------
            # Draw velocity arrow only for valid targets
            # --------------------------------------------------

            if SHOW_VELOCITY_ARROWS and valid:

                plt.quiver(
                    x,
                    y,
                    vx,
                    vy,
                    angles='xy',
                    scale_units='xy',
                    scale=5.0,
                    color='#ff1744',
                    width=0.005,
                    headwidth=4,
                    headlength=5,
                    zorder=4
                )

            # --------------------------------------------------
            # Label
            # --------------------------------------------------

            if SHOW_LABELS:

                plt.text(
                    x + 0.15,
                    y + 0.15,
                    (
                        f"ID:{target_id}\n"
                        f"Hits:{hits}\n"
                        f"Age:{track_age:.1f}s\n"
                        f"RCS:{rcs:.1f}\n"
                        f"Dyn:{dyn_prop}\n"
                        f"Sec:{sector}\n"
                        f"Vy:{vy:+.1f}"
                    ),
                    color='#ffffff',
                    fontsize=8,
                    bbox=dict(
                        boxstyle='round,pad=0.2',
                        facecolor='#1e1e1e',
                        alpha=0.75,
                        edgecolor=label_color
                    ),
                    zorder=5
                )

        # Remove stale tracks

        for rid in remove_ids:

            del node_ref.targets[rid]

            if rid in node_ref.kalman_filters:
                del node_ref.kalman_filters[rid]

        # Remove Kalman instances whose grace period has expired
        # (target still exists and is still being tracked raw, it
        # has just been invalid for too long to keep smoothing).

        for kid in kalman_remove_ids:

            if kid in node_ref.kalman_filters:
                del node_ref.kalman_filters[kid]

    # ----------------------------------------------------------
    # Statistics
    # ----------------------------------------------------------

    plt.text(
        -4.8,
        38,
        (
            f"Total Tracks : {total_count}\n"
            f"Valid Tracks : {valid_count}"
        ),
        fontsize=10,
        color='white',
        bbox=dict(
            boxstyle='round',
            facecolor='#222222',
            alpha=0.8
        )
    )

    plt.legend(
        loc='upper right',
        facecolor='#1e1e1e',
        edgecolor='#333333',
        labelcolor='#ffffff',
        fontsize=8
    )


def ros_spin():

    global node_ref

    rclpy.spin(node_ref)


def main(args=None):

    global node_ref
    global anim

    rclpy.init(args=args)

    node_ref = RadarPlotter()

    spin_thread = threading.Thread(
        target=ros_spin,
        daemon=True
    )

    spin_thread.start()

    plt.style.use('dark_background')

    fig = plt.figure(
        figsize=(12, 7)
    )

    anim = FuncAnimation(
        fig,
        update,
        interval=UPDATE_INTERVAL_MS,
        cache_frame_data=False
    )

    plt.show(block=True)

    node_ref.destroy_node()

    rclpy.shutdown()


if __name__ == '__main__':
    main()